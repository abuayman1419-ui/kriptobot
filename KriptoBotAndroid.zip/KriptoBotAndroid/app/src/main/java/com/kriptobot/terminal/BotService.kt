package com.kriptobot.terminal

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import java.security.SecureRandom
import kotlin.concurrent.thread

object BotState {
    @Volatile var error: String? = null
    @Volatile var started = false
}

object Prefs {
    /** Uygulamaya özel rastgele şifre: telefondaki başka uygulamalar bota erişemesin. */
    fun pin(ctx: Context): String {
        val sp = ctx.getSharedPreferences("bot", Context.MODE_PRIVATE)
        sp.getString("pin", null)?.let { return it }
        val b = ByteArray(24)
        SecureRandom().nextBytes(b)
        val p = b.joinToString("") { "%02x".format(it) }
        sp.edit().putString("pin", p).apply()
        return p
    }
}

class BotService : Service() {
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("bot", "Bot çalışıyor", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "bot") else Notification.Builder(this))
            .setContentTitle("Kripto Bot çalışıyor")
            .setContentText("Piyasa taranıyor. Panel için dokun.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }

        if (!BotState.started) {
            BotState.started = true
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "kriptobot:run").apply { acquire() }
            val pin = Prefs.pin(this)
            val dir = filesDir.absolutePath
            thread(name = "bot-python") {
                try {
                    if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                    Python.getInstance().getModule("runner").callAttr("start", dir, pin)
                    BotState.error = "Bot beklenmedik şekilde durdu."
                } catch (t: Throwable) {
                    Log.e("KriptoBot", "bot hatası", t)
                    val msg = (t.message ?: t.toString()).take(2500)
                    BotState.error = msg
                    try { File(filesDir, "bot_error.txt").writeText(msg) } catch (_: Exception) {}
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        wake?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
