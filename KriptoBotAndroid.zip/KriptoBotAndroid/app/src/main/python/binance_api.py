"""Binance USDT-M Futures: yalnızca OKUMA (public endpoint). Emir/hesap endpoint'i yoktur."""
import asyncio
import json
import time

import aiohttp
import pandas as pd
import websockets

REST = "https://fapi.binance.com"
WS = "wss://fstream.binance.com"
COLS = ["t", "o", "h", "l", "c", "v", "qv", "tb"]


def rows_to_df(rows):
    df = pd.DataFrame(rows, columns=COLS)
    return df.astype({k: float for k in COLS[1:]})


class Futures:
    def __init__(self):
        self.s = None
        self.filters = {}

    async def get(self, path, **params):
        if self.s is None:
            self.s = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15))
        async with self.s.get(REST + path, params=params) as r:
            r.raise_for_status()
            return await r.json()

    async def universe(self, cfg):
        """Tüm TRADING durumundaki USDT perpetual sözleşmeler -> hacme göre ilk max_symbols."""
        info = await self.get("/fapi/v1/exchangeInfo")
        self.filters = {}
        for x in info["symbols"]:
            fl = {f["filterType"]: f for f in x.get("filters", [])}
            lot = fl.get("MARKET_LOT_SIZE") or fl.get("LOT_SIZE") or {}
            self.filters[x["symbol"]] = {"step": float(lot.get("stepSize", 0) or 0), "minq": float(lot.get("minQty", 0) or 0),
                                         "notional": float((fl.get("MIN_NOTIONAL") or {}).get("notional", 5) or 5)}
        ok = {s["symbol"] for s in info["symbols"] if s["contractType"] == "PERPETUAL"
              and s["quoteAsset"] == "USDT" and s["status"] == "TRADING"}
        tk = await self.get("/fapi/v1/ticker/24hr")
        qv = {t["symbol"]: float(t["quoteVolume"]) for t in tk if t["symbol"] in ok}
        syms = sorted((s for s in qv if qv[s] >= cfg.min_qv24), key=lambda s: -qv[s])[:cfg.max_symbols]
        if "BTCUSDT" not in syms:
            syms.insert(0, "BTCUSDT")
        return syms, qv

    async def klines(self, sym, interval, limit=100):
        raw = await self.get("/fapi/v1/klines", symbol=sym, interval=interval, limit=limit)
        # [openTime, o, h, l, c, v, closeTime, qv, trades, takerBuyBase, ...]
        return [[r[0], r[1], r[2], r[3], r[4], r[5], r[7], r[9]] for r in raw]

    async def price(self, sym):
        return float((await self.get("/fapi/v1/ticker/price", symbol=sym))["price"])

    async def depth(self, sym, limit=20):
        return await self.get("/fapi/v1/depth", symbol=sym, limit=limit)

    async def oi_change(self, sym):
        h = await self.get("/futures/data/openInterestHist", symbol=sym, period="5m", limit=7)
        if len(h) < 2:
            return None
        a, b = float(h[0]["sumOpenInterest"]), float(h[-1]["sumOpenInterest"])
        return b / a - 1 if a else None

    async def funding_all(self):
        d = await self.get("/fapi/v1/premiumIndex")
        return {x["symbol"]: float(x["lastFundingRate"]) for x in d}

    async def close(self):
        if self.s:
            await self.s.close()


class Stream:
    """1m kline akışı. Her sembol için son ~300 satır tutar; son satır oluşmakta olan mumdur."""

    def __init__(self, symbols, cfg):
        self.symbols, self.cfg = symbols, cfg
        self.rows = {s: [] for s in symbols}
        self.price = {}
        self.ts = {}
        self.connected = 0
        self.expected = 0
        self.msgs = 0
        self.last_err = ""
        self.tasks = []

    def seed(self, sym, rows):
        self.rows[sym] = rows[-300:]
        self.price[sym] = float(rows[-1][4])
        self.ts[sym] = time.time()

    def frame(self, sym):
        """Yalnızca kapanmış mumlar (son, oluşmakta olan mum atılır)."""
        r = self.rows.get(sym, [])
        return rows_to_df(r[:-1]) if len(r) > 2 else None

    def age(self, sym):
        return time.time() - self.ts.get(sym, 0)

    def healthy(self):
        return self.expected > 0 and self.connected == self.expected

    def _on(self, k):
        s = k["s"]
        row = [k["t"], k["o"], k["h"], k["l"], k["c"], k["v"], k["q"], k["V"]]
        buf = self.rows[s]
        if buf and buf[-1][0] == k["t"]:
            buf[-1] = row
        else:
            buf.append(row)
            del buf[:-300]
        self.price[s] = float(k["c"])
        self.ts[s] = time.time()
        self.msgs += 1

    async def _conn(self, chunk):
        url = WS + "/stream?streams=" + "/".join(f"{s.lower()}@kline_1m" for s in chunk)
        delay = 1
        while True:
            try:
                async with websockets.connect(url, ping_interval=20, ping_timeout=30,
                                              open_timeout=15, max_size=None) as ws:
                    self.connected += 1
                    delay = 1
                    try:
                        while True:   # 30 sn sessizlik = kopuk say, yeniden bağlan
                            msg = await asyncio.wait_for(ws.recv(), timeout=30)
                            self._on(json.loads(msg)["data"]["k"])
                    finally:
                        self.connected -= 1
            except Exception as e:
                self.last_err = f"{type(e).__name__}: {str(e)[:100]}"
            await asyncio.sleep(delay)
            delay = min(delay * 2, 30)

    def start(self):
        n = self.cfg.stream_chunk
        chunks = [self.symbols[i:i + n] for i in range(0, len(self.symbols), n)]
        self.expected = len(chunks)
        self.tasks = [asyncio.create_task(self._conn(c)) for c in chunks]
        return self.tasks
