"""PAPER işlem motoru + risk yöneticisi. Gerçek emir göndermez; hiçbir borsa çağrısı içermez."""
import json
import os
import time
from collections import deque
from datetime import datetime, timezone


class PaperEngine:
    def __init__(self, cfg):
        self.cfg = cfg
        self.balance = cfg.start_balance
        self.pos = {}
        self.closed = []
        self.consec_losses = 0
        self.cooldown_until = 0.0
        self.peak = cfg.start_balance
        self.max_dd = 0.0
        self.day = self._today()
        self.day_start = cfg.start_balance
        self.halted = None
        self.safe_mode = False
        self.paused = False
        self.demo_on = False
        self.queue = []
        self.eq_hist = deque(maxlen=720)
        os.makedirs(cfg.log_dir, exist_ok=True)
        self.log_path = os.path.join(cfg.log_dir, "paper_trades.jsonl")

    @staticmethod
    def _today():
        return datetime.now(timezone.utc).strftime("%Y-%m-%d")

    # ---------- değerleme ----------
    def unrealized(self, prices):
        t = 0.0
        for s, p in self.pos.items():
            px = prices.get(s, p["entry"])
            t += (px - p["entry"]) * p["qty_open"] * p["dir"]
        return t

    def equity(self, prices):
        return self.balance + self.unrealized(prices)

    # ---------- risk kapıları ----------
    def can_open(self, symbol, now):
        c = self.cfg
        if self.day != self._today():
            self.day, self.day_start, self.halted = self._today(), self.balance, None
        if self.paused:
            return False, "Alım-satım elle durduruldu"
        if self.safe_mode:
            return False, "Veri akışı güvenli modda"
        if self.halted:
            return False, self.halted
        if symbol in self.pos:
            return False, "Aynı coinde açık pozisyon var"
        if len(self.pos) >= c.max_positions:
            return False, "Maksimum açık pozisyon"
        if now < self.cooldown_until:
            return False, "Üst üste zarar sonrası bekleme"
        if self.balance - self.day_start <= -c.daily_loss_pct * self.day_start:
            self.halted = "Günlük zarar limiti doldu"
            return False, self.halted
        return True, ""

    # ---------- işlem açma ----------
    def open(self, opp, price, now):
        c = self.cfg
        ok, why = self.can_open(opp["symbol"], now)
        if not ok:
            return False, why
        if abs(price - opp["price"]) > c.max_slippage_atr * opp["atr"]:
            return False, "Fiyat sinyalden fazla kaçtı"
        d = 1 if opp["side"] == "LONG" else -1
        r = abs(opp["price"] - opp["sl"])            # 1R (fiyat cinsinden)
        sl = price - d * r
        tps = [price + d * k * r for k in c.tp_r]
        risk_amt = self.balance * c.risk_pct
        qty = risk_amt / r
        max_notional = self.balance * c.margin_pct * c.leverage
        qty = min(qty, max_notional / price)
        if qty * price < 5:
            return False, "Pozisyon çok küçük"
        fee = qty * price * c.taker_fee
        self.balance -= fee
        self.pos[opp["symbol"]] = {
            "symbol": opp["symbol"], "side": opp["side"], "dir": d, "entry": price, "qty": qty,
            "qty_open": qty, "sl": sl, "tps": tps, "tp_hit": 0, "leverage": c.leverage,
            "margin": qty * price / c.leverage, "opened": now, "fees": fee, "realized": 0.0,
            "score": opp["score"], "reason": opp["note"], "hist": deque(maxlen=40)}
        if self.demo_on:
            self.queue.append({"kind": "open", "sym": opp["symbol"], "side": opp["side"], "qty": qty, "reduce": False})
        return True, ""

    # ---------- fiyat takibi ----------
    def mark(self, prices, now):
        c = self.cfg
        for s in list(self.pos):
            p = self.pos[s]
            px = prices.get(s)
            if px is None:
                continue
            d = p["dir"]
            p["hist"].append((now, px))
            old = next((x for t, x in p["hist"] if now - t <= 60), None)
            if old and (px - old) / old * 100 * d <= -c.panic_move_pct:
                self._close(p, p["qty_open"], px, "Ani volatilite koruması", now)
                continue
            if (px - p["sl"]) * d <= 0:
                self._close(p, p["qty_open"], px, "Stop Loss" if p["tp_hit"] == 0 else "Stop (kâr korumalı)", now)
                continue
            while p["tp_hit"] < len(p["tps"]) and (px - p["tps"][p["tp_hit"]]) * d >= 0:
                i = p["tp_hit"]
                last_tp = i == len(p["tps"]) - 1
                q = p["qty_open"] if last_tp else min(p["qty_open"], p["qty"] * c.tp_split[i])
                p["tp_hit"] += 1
                if i == 0:
                    p["sl"] = p["entry"]                # TP1 sonrası başa baş
                elif i == 1:
                    p["sl"] = p["tps"][0]               # TP2 sonrası kâr kilidi
                self._close(p, q, p["tps"][i], f"TP{i + 1}", now)
                if s not in self.pos:
                    break
            if s in self.pos and now - p["opened"] > c.max_hold_minutes * 60:
                self._close(p, p["qty_open"], px, "Zaman aşımı", now)

    def _close(self, p, qty, price, reason, now):
        c = self.cfg
        pnl = (price - p["entry"]) * qty * p["dir"]
        fee = price * qty * c.taker_fee
        self.balance += pnl - fee
        p["realized"] += pnl - fee
        p["fees"] += fee
        p["qty_open"] -= qty
        if self.demo_on:
            self.queue.append({"kind": "close", "sym": p["symbol"], "side": p["side"], "qty": qty, "reduce": True})
        full = p["qty_open"] <= 1e-12
        rec = {"time": datetime.fromtimestamp(now, timezone.utc).isoformat(timespec="seconds"),
               "symbol": p["symbol"], "side": p["side"], "entry": p["entry"], "exit": price,
               "qty": qty, "pnl": round(pnl - fee, 4), "reason": reason,
               "final": full, "duration_s": int(now - p["opened"]), "leverage": p["leverage"],
               "score": p["score"], "open_reason": p["reason"],
               "trade_total": round(p["realized"], 4) if full else None}
        self.closed.append(rec)
        with open(self.log_path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
        self.peak = max(self.peak, self.balance)
        self.max_dd = max(self.max_dd, (self.peak - self.balance) / self.peak)
        if full:
            total = p["realized"]
            self.consec_losses = self.consec_losses + 1 if total < 0 else 0
            if self.consec_losses >= c.max_consec_losses:
                self.cooldown_until = now + c.cooldown_minutes * 60
                self.consec_losses = 0
            del self.pos[p["symbol"]]
            p["total"] = total

    # ---------- elle kontrol ----------
    def close_all(self, prices, now, reason="Elle kapatıldı"):
        n = 0
        for s in list(self.pos):
            p = self.pos[s]
            self._close(p, p["qty_open"], prices.get(s, p["entry"]), reason, now)
            n += 1
        return n

    def abort(self, sym):
        """Demo giriş emri reddedilirse sanal pozisyonu geri al."""
        p = self.pos.pop(sym, None)
        if p:
            self.balance += p["fees"]

    def reset(self):
        if self.pos:
            return False
        self.balance = self.peak = self.cfg.start_balance
        self.day_start, self.max_dd, self.closed, self.halted = self.balance, 0.0, [], None
        self.consec_losses, self.cooldown_until = 0, 0.0
        return True

    # ---------- istatistik ----------
    def stats(self):
        # Pozisyon bazında toplama için kayıtları sembol+açılış değil, parça bazında kullanıyoruz.
        pnls = [r["pnl"] for r in self.closed]
        wins = [x for x in pnls if x > 0]
        losses = [x for x in pnls if x <= 0]
        gl = -sum(losses)
        longs = [r["pnl"] for r in self.closed if r["side"] == "LONG"]
        shorts = [r["pnl"] for r in self.closed if r["side"] == "SHORT"]
        sr = lambda a: round(100 * sum(1 for x in a if x > 0) / len(a), 1) if a else None
        return {
            "start_balance": self.cfg.start_balance, "balance": round(self.balance, 2),
            "net_pnl": round(self.balance - self.cfg.start_balance, 2),
            "fills": len(pnls), "win_rate": sr(pnls),
            "profit_factor": round(sum(wins) / gl, 2) if gl > 0 else None,
            "avg_win": round(sum(wins) / len(wins), 3) if wins else None,
            "avg_loss": round(-gl / len(losses), 3) if losses else None,
            "max_drawdown_pct": round(self.max_dd * 100, 2),
            "long_success": sr(longs), "short_success": sr(shorts),
            "halted": self.halted, "safe_mode": self.safe_mode, "paused": self.paused,
        }
