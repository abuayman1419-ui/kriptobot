"""Telefondan / ağdan erişim için şifre koruması (yalnızca standart kütüphane).

- Şifre ortam değişkeninden gelir (TERMINAL_PIN); diske yazılmaz.
- Giriş başarılı olursa imzalı, süreli bir çerez verilir (30 gün). Şifre değişirse tüm oturumlar düşer.
- Art arda yanlış denemede girişler geçici kilitlenir (kaba kuvvet koruması).
"""
import hashlib
import hmac
import os
import secrets
import time

MIN_LEN = 6
SESSION_DAYS = 30
MAX_FAILS = 8          # pencere içinde izin verilen yanlış deneme
WINDOW = 600           # sn


class Auth:
    def __init__(self, pin="", key_path=None):
        self.pin = pin or ""
        self.enabled = bool(self.pin)
        self.fails = []
        self._pin_hash = hashlib.sha256(self.pin.encode()).digest()
        self._key = self._load_key(key_path)

    @staticmethod
    def _load_key(path):
        if path:
            try:
                with open(path, "rb") as fh:
                    k = fh.read()
                if len(k) >= 32:
                    return k
            except OSError:
                pass
        k = secrets.token_bytes(32)
        if path:
            try:
                os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
                with open(path, "wb") as fh:
                    fh.write(k)
                try:
                    os.chmod(path, 0o600)
                except OSError:
                    pass
            except OSError:
                pass   # kalıcı olmazsa yeniden başlatınca oturumlar düşer, sorun değil
        return k

    def _sig(self, exp):
        msg = b"v1|" + str(exp).encode() + b"|" + self._pin_hash
        return hmac.new(self._key, msg, hashlib.sha256).hexdigest()

    def locked(self, now=None):
        now = now or time.time()
        self.fails = [t for t in self.fails if now - t < WINDOW]
        return len(self.fails) >= MAX_FAILS

    def login(self, pin, now=None):
        """(token, hata) döndürür. Başarılıysa hata None."""
        now = now or time.time()
        if not self.enabled:
            return None, "Şifre koruması kapalı"
        if self.locked(now):
            return None, "Çok fazla yanlış deneme. Birkaç dakika sonra tekrar deneyin."
        ok = hmac.compare_digest(hashlib.sha256((pin or "").encode()).digest(), self._pin_hash)
        if not ok:
            self.fails.append(now)
            return None, "Şifre yanlış"
        self.fails.clear()
        exp = int(now + SESSION_DAYS * 86400)
        return f"{exp}.{self._sig(exp)}", None

    def valid(self, token, now=None):
        if not self.enabled:
            return True
        try:
            exp_s, sig = (token or "").split(".", 1)
            exp = int(exp_s)
        except ValueError:
            return False
        if exp < (now or time.time()):
            return False
        return hmac.compare_digest(sig, self._sig(exp))


def is_loopback(host):
    return host in ("127.0.0.1", "localhost", "::1")


def local_ip():
    """Aynı Wi-Fi ağındaki cihazların kullanacağı yerel IP (bulunamazsa None)."""
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))     # paket gönderilmez, yalnızca yol seçilir
        return s.getsockname()[0]
    except OSError:
        return None
    finally:
        s.close()


LOGIN_HTML = """<!DOCTYPE html>
<html lang="tr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0b0f17"><meta name="apple-mobile-web-app-capable" content="yes">
<link rel="manifest" href="/manifest.webmanifest"><link rel="apple-touch-icon" href="/apple-touch-icon.png">
<title>CRYPTO AI TERMINAL - Giriş</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;background:#0b0f17;color:#d8e0ee;font:16px system-ui,sans-serif;display:flex;align-items:center;justify-content:center;padding:20px}
form{width:100%;max-width:340px;background:#121826;border:1px solid #1f2a3d;border-radius:14px;padding:22px}
h1{font-size:16px;letter-spacing:.08em;margin:0 0 4px}p{color:#7d8ba3;font-size:13px;margin:0 0 16px}
input{width:100%;font:inherit;background:#0b1220;color:#d8e0ee;border:1px solid #2b3a5c;border-radius:9px;padding:12px}
button{width:100%;margin-top:12px;font:inherit;font-weight:700;background:#2563eb;color:#fff;border:0;border-radius:9px;padding:12px}
#e{color:#ef4444;font-size:13px;min-height:18px;margin-top:10px}
</style></head><body>
<form onsubmit="go(event)"><h1>CRYPTO AI TERMINAL</h1><p>Devam etmek için şifreyi girin.</p>
<input id="p" type="password" autocomplete="current-password" placeholder="Şifre" autofocus>
<button>Giriş</button><div id="e"></div></form>
<script>
async function go(ev){ev.preventDefault();const e=document.getElementById('e');e.textContent='';
try{const r=await fetch('/login',{method:'POST',headers:{'Content-Type':'application/json','X-Requested-With':'terminal'},body:JSON.stringify({pin:document.getElementById('p').value})});
const d=await r.json();if(d.ok)location.href='/';else e.textContent=d.msg||'Hata'}catch(x){e.textContent='Sunucuya ulaşılamadı'}}
</script></body></html>
"""
