"""Binance DEMO hesabı emir yürütücüsü. YALNIZCA demo/testnet adreslerine bağlanır; canlı (fapi.binance.com) adresi kodda YOKTUR.
Anahtarlar yalnızca bellekte tutulur, diske yazılmaz, loglanmaz."""
import hashlib
import hmac
import time
import urllib.parse
from collections import deque
from decimal import ROUND_DOWN, Decimal

BASES = {"demo": "https://demo-fapi.binance.com", "testnet": "https://testnet.binancefuture.com"}


class Demo:
    def __init__(self):
        self.key = self.secret = None
        self.env = "demo"
        self.connected = False
        self.balance = None
        self.avail = None
        self.hedge = False
        self.offset = 0
        self.err = ""
        self.log = deque(maxlen=60)
        self.lev_set = set()
        self.s = None

    def forget(self):
        self.key = self.secret = None
        self.connected, self.balance, self.avail, self.err = False, None, None, ""
        self.lev_set.clear()

    async def _req(self, method, path, signed=True, **params):
        import aiohttp
        if self.s is None:
            self.s = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15))
        base = BASES[self.env]
        headers = {}
        if signed:
            params["timestamp"] = int(time.time() * 1000) + self.offset
            params["recvWindow"] = 10000
            q = urllib.parse.urlencode(params)
            sig = hmac.new(self.secret.encode(), q.encode(), hashlib.sha256).hexdigest()
            q += "&signature=" + sig
            headers["X-MBX-APIKEY"] = self.key
        else:
            q = urllib.parse.urlencode(params)
        async with self.s.request(method, f"{base}{path}?{q}", headers=headers) as r:
            txt = await r.text()
            if r.status >= 400:
                raise RuntimeError(f"HTTP {r.status}: {txt[:160]}")
            import json
            return json.loads(txt)

    async def connect(self, key, secret, env):
        if env not in BASES:
            raise ValueError("Geçersiz ortam")
        self.key, self.secret, self.env = key.strip(), secret.strip(), env
        self.connected = False
        t = await self._req("GET", "/fapi/v1/time", signed=False)
        self.offset = int(t["serverTime"]) - int(time.time() * 1000)
        try:
            acc = await self._req("GET", "/fapi/v3/account")
        except Exception:
            acc = await self._req("GET", "/fapi/v2/account")
        self.balance = float(acc.get("totalWalletBalance", 0))
        self.avail = float(acc.get("availableBalance", 0))
        try:
            self.hedge = bool((await self._req("GET", "/fapi/v1/positionSide/dual")).get("dualSidePosition"))
        except Exception:
            self.hedge = False
        self.connected, self.err = True, ""
        self.note(f"Bağlandı ({env}), bakiye {self.balance:.2f} USDT" + (", hedge modu" if self.hedge else ""))

    def note(self, msg):
        self.log.appendleft({"t": time.strftime("%H:%M:%S"), "m": msg})

    @staticmethod
    def fit(qty, flt):
        step = Decimal(str(flt.get("step") or 0))
        q = Decimal(str(qty))
        if step > 0:
            q = (q / step).to_integral_value(rounding=ROUND_DOWN) * step
        return q

    async def place(self, sym, side, qty, reduce, flt, lev, price):
        q = self.fit(qty, flt)
        if q <= 0 or float(q) < flt.get("minq", 0) or (not reduce and float(q) * price < flt.get("notional", 5)):
            raise RuntimeError(f"{sym}: miktar borsa limitlerinin altında ({q})")
        if not reduce and sym not in self.lev_set:
            try:
                await self._req("POST", "/fapi/v1/marginType", symbol=sym, marginType="CROSSED")
            except Exception:
                pass            # zaten CROSSED ise hata döner, önemsiz
            await self._req("POST", "/fapi/v1/leverage", symbol=sym, leverage=int(lev))
            self.lev_set.add(sym)
        long = side == "LONG"
        order_side = ("BUY" if long else "SELL") if not reduce else ("SELL" if long else "BUY")
        p = {"symbol": sym, "side": order_side, "type": "MARKET", "quantity": format(q, "f"), "newOrderRespType": "RESULT"}
        if self.hedge:
            p["positionSide"] = "LONG" if long else "SHORT"
        elif reduce:
            p["reduceOnly"] = "true"
        r = await self._req("POST", "/fapi/v1/order", **p)
        self.note(f"{'KAPAT' if reduce else 'AÇ'} {sym} {side} {p['quantity']} @ {r.get('avgPrice', '?')}")
        return r

    async def refresh_balance(self):
        try:
            acc = await self._req("GET", "/fapi/v2/account")
            self.balance, self.avail = float(acc["totalWalletBalance"]), float(acc["availableBalance"])
        except Exception as e:
            self.err = str(e)[:120]
