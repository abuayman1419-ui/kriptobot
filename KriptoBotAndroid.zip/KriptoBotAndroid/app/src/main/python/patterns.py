"""Mum formasyonu ve kırılım tespiti (yalnızca KAPANMIŞ mumlar).
Her sonuç: name, bias (+ yükseliş / - düşüş, -1..1), invalid (geçersizleşme seviyesi)."""


def detect(df):
    out = []
    if len(df) < 25:
        return out
    o, h, l, c, v = (df[k].values for k in ("o", "h", "l", "c", "v"))
    i = len(df) - 1
    body = lambda k: abs(c[k] - o[k])
    rng = lambda k: max(h[k] - l[k], 1e-12)
    up = lambda k: c[k] > o[k]
    avg6 = sum(c[i - 6:i]) / 6

    if not up(i - 1) and up(i) and c[i] >= o[i - 1] and o[i] <= c[i - 1] and body(i) > body(i - 1):
        out.append({"name": "Bullish Engulfing", "bias": 0.6, "invalid": l[i]})
    if up(i - 1) and not up(i) and c[i] <= o[i - 1] and o[i] >= c[i - 1] and body(i) > body(i - 1):
        out.append({"name": "Bearish Engulfing", "bias": -0.6, "invalid": h[i]})
    lw = min(o[i], c[i]) - l[i]
    uw = h[i] - max(o[i], c[i])
    if body(i) > 0 and lw >= 2 * body(i) and uw <= 0.3 * body(i) and c[i] < avg6:
        out.append({"name": "Hammer", "bias": 0.5, "invalid": l[i]})
    if body(i) > 0 and uw >= 2 * body(i) and lw <= 0.3 * body(i) and c[i] > avg6:
        out.append({"name": "Shooting Star", "bias": -0.5, "invalid": h[i]})
    if body(i) <= 0.1 * rng(i):
        out.append({"name": "Doji", "bias": 0.0, "invalid": None})
    if not up(i - 2) and body(i - 1) < 0.4 * body(i - 2) and up(i) and c[i] > (o[i - 2] + c[i - 2]) / 2:
        out.append({"name": "Morning Star", "bias": 0.7, "invalid": min(l[i - 1], l[i])})
    if up(i - 2) and body(i - 1) < 0.4 * body(i - 2) and not up(i) and c[i] < (o[i - 2] + c[i - 2]) / 2:
        out.append({"name": "Evening Star", "bias": -0.7, "invalid": max(h[i - 1], h[i])})
    if all(up(k) for k in (i - 2, i - 1, i)) and c[i] > c[i - 1] > c[i - 2]:
        out.append({"name": "Three White Soldiers", "bias": 0.6, "invalid": l[i - 2]})
    if all(not up(k) for k in (i - 2, i - 1, i)) and c[i] < c[i - 1] < c[i - 2]:
        out.append({"name": "Three Black Crows", "bias": -0.6, "invalid": h[i - 2]})
    # Kırılım / Fakeout (önceki 20 mum)
    hi, lo = max(h[i - 20:i]), min(l[i - 20:i])
    vavg = sum(v[i - 20:i]) / 20
    if c[i] > hi:
        strong = v[i] > 1.3 * vavg
        out.append({"name": "Direnç Kırılımı (hacimli)" if strong else "Direnç Kırılımı (hacim zayıf)",
                    "bias": 0.8 if strong else 0.2, "invalid": hi})
    elif h[i] > hi:
        out.append({"name": "Fake Breakout (üst)", "bias": -0.7, "invalid": h[i]})
    if c[i] < lo:
        strong = v[i] > 1.3 * vavg
        out.append({"name": "Destek Kırılımı (hacimli)" if strong else "Destek Kırılımı (hacim zayıf)",
                    "bias": -0.8 if strong else -0.2, "invalid": lo})
    elif l[i] < lo:
        out.append({"name": "Fake Breakout (alt)", "bias": 0.7, "invalid": l[i]})
    return out
